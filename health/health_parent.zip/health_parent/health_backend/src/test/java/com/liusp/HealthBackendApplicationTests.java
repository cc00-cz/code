package com.liusp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
