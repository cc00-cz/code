package com.liusp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCommonApplication {

    public static void main(String[] args) {
        SpringApplication.run(HealthCommonApplication.class, args);
    }

}
